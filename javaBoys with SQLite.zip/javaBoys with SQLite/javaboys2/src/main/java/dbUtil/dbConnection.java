/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dbUtil;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author bai3tibuni
 */
public class dbConnection {
    //private static final String USERNAME = "root";
    //private static final String PASSWORD = "manager";
    //private static final String CONN = "jdbc:mysql://localhost:3306/javab";
    private static final String SQCONN = "jdbc:sqlite:dbJavaSQL.sqlite";

    /**
     * This method get connection to the database
     * @return Connection
     * @throws SQLException
     */
    public static Connection getConnection() throws SQLException {
        try{ 
            Class.forName("org.sqlite.JDBC");
            return DriverManager.getConnection(SQCONN);
            
        }
        catch (ClassNotFoundException ex){
            ex.printStackTrace();
            JOptionPane.showMessageDialog(null, ex + " No connection to dataBase");
        }
        return null;
    }
}
